/*Desarrolle una aplicación en Java que determine si alguno de los clientes de una tienda de departamentos se ha
excedido del límite de crédito en una cuenta. Para cada cliente se tienen los siguientes datos:
a) el saldo al inicio del mes.
b) el total de abonos en el mes.
c) el total de deducciones aplicadas a la cuenta del cliente en el mes.
d) el límite de crédito permitido.
El programa debe contar con estos datos cargados en variables de tipo entera, y debe calcular el nuevo saldo (= saldo
inicial + abonos - deducciones), mostrar el nuevo balance y determinar si éste excede el límite de crédito del cliente.
Para los clientes cuyo límite de crédito sea excedido, el programa debe mostrar el mensaje "Se excedió el límite de su
crédito”.
*/
package punto2;
public class codigo_punto2 {
    public static void main(String[] args) {
        int [] sal_inicio = {3000000,4000000,1200000};
        int[]abono_mes = {120000,200000,150000};
        int []total_deduciones= {413000,210000,250000};
        int []nuevosaldo= new int [3];
        final int limite_creditos=2500000;
        for (int i=0;i<3;i++){
            nuevosaldo[i]=(sal_inicio[i]+abono_mes[i]-total_deduciones[i]);
            if (nuevosaldo[i]>limite_creditos){
                System.out.print(" el nuevo saldo del cliente "+ (i+1) +" es: "+ nuevosaldo[i]+" pesos,");
                System.out.println("se excedio el limite de su credito de: " +" "+limite_creditos);                 
            }
            else{
                System.out.print(" el nuevo saldo del cliente "+ (i+1) +" es: "+ nuevosaldo[i]+" pesos ");
            }        
        }
    } 
}