/*Un vendedor minorista en línea requiere un informe de las ventas del día. Para ello cuenta con tres arreglos de n
elementos cada uno: A, B y C. El primero almacena el código de los productos vendidos en el día, El segundo almacena
el valor de venta de cada producto, y el tercero la cantidad de unidades vendidas de cada producto.
 Requiere un aplicativo que le calcule rápidamente los siguientes datos:
• Total productos vendidos en el día.
• Total ingresos por ventas del día.
• El producto más vendido.
• El producto más costoso vendido*/
package punto1;
import java.util.Scanner;
public class codigo_punto1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int tamaño;
        System.out.println("ingrese el tamaño de su vector: ");
        tamaño=entrada.nextInt();
        int suma_uni=0;
        int suma2=0;
        int suma_uni2=0;
	int[] codigos = new int[tamaño];
        int[] valor_producto= new int [tamaño];
        int[] unidades_producto= new int [tamaño];
        int []multi= new int [tamaño];
        int mayor2=0;
        int mayor=0;
	for (int i = 0; i < tamaño; i++) {
            System.out.print("Ingrese el codigo del producto " + (i+1) + " :");
            codigos[i] = entrada.nextInt();
        }
        for (int i = 0; i < tamaño; i++){
            System.out.print("Ingrese el valor del producto " + (i+1) + " :");
            valor_producto[i]=entrada.nextInt(); 
        }
        for (int i = 0; i < tamaño; i++){
            System.out.print("Ingrese la cantidad de unidades vendidas del producto " + (i+1) + " :");
            unidades_producto[i]=entrada.nextInt(); 
        }
        for (int i=0; i<tamaño;i++){
            multi[i]=valor_producto[i]*unidades_producto[i];//multiplicacion de arreglos
            suma2 += multi[i];
        }
        //suma
        int pos=-1;
        for (int g=0; g< valor_producto.length;g++){
            suma_uni2 += valor_producto[g];
            if (mayor2<valor_producto[g]){
                mayor2=valor_producto[g];
            }
        }
        for (int d=0; d< unidades_producto.length;d++){
            suma_uni += unidades_producto[d];
            if (mayor<unidades_producto[d]){
                mayor=unidades_producto[d];
                pos=d;
            }
        }
        System.out.println("total de unidades vendidas al dia: " + suma_uni);
        System.out.println("el total de ingresos por ventas al dia: "+ suma2);
        System.out.println("el producto mas vendido es el: "+ (pos+1));
        System.out.println("el producto mas costoso vendido es: "+ mayor2);
    }      
}