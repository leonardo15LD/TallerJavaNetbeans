/*
Una empresa grande paga a sus vendedores mediante comisiones. Los vendedores reciben $200 por semana, más el
9% de sus ventas brutas durante esa semana. Por ejemplo, un vendedor que vende $5,000 de mercancía en una
semana, recibe $200 más el 9% de 5,000, o un total de $650 en esa semana.
Del mismo modo, la empresa premia a los vendedores que cumplan los objetivos de venta con un incremento en el
pago de la semana, de acuerdo a las siguientes categorías de vendedores:
Categoría A – incrementa el pago semanal en 5% si las ventas superan $3000, en 7% sin son entre $5000 y $7000, y
10% si superan los $7000.
Categoría B – incrementa el pago semanal en 7% si las ventas superan $5000, %10 si son entre %10000 y $15000,
13% si superan los $15000.
Si usted cuenta con el registro de ventas diarias realizadas por un vendedor almacenados en un arreglo de 7 posiciones
(una para cada día de la semana), ¿cuál sería el pago semanal del vendedor en cada categoría?
 */
package punto3;
import java.util.Scanner;
public class codigo_punto3 {
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        int []valor= new int [7];
        int suma=0;
        int pago_semanalA;
        for (int i=0; i<7; i++){
            System.out.println("ingrese el valor de las ventas diarias del dia "+(i+1));
            valor[i]=entrada.nextInt();
        }
        for (int x= 0;x<valor.length;x++){
            suma+=valor[x];   
        }
        if (suma>3000&&suma<5000){
            int por5;
            por5=(suma*5/100);
            pago_semanalA=(suma+por5+200);
            System.out.println("el pago semanal del vendedor en la categoria A es: "+pago_semanalA);        
        }
        else{
            if (suma>=5000&&suma<=7000){
                int por7;
                por7=(suma*7/100);
                pago_semanalA=(suma+por7+200);
                System.out.println("el pago semanal del vendedor en la categoria A es: "+pago_semanalA);
            }
            else{    
                int por10;
                por10=(suma*10/100);
                pago_semanalA=(suma+por10+200);
                System.out.println("el pago semanal del vendedor en la categoria A es: "+pago_semanalA);
            }
        } 
        //categoriaB
        int suma2;
        suma2=suma;
        if (suma2>5000&&suma2<10000){
            int por5;
            por5=(suma2*7/100);
            pago_semanalA=(suma+por5+200);
            System.out.println("el pago semanal del vendedor en la categoria B es: "+pago_semanalA);        
        }
        else{
            if (suma2>=10000&&suma2<=15000){
                int por7;
                por7=(suma2*10/100);
                pago_semanalA=(suma2+por7+200);
                System.out.println("el pago semanal del vendedor en la categoria B es: "+pago_semanalA);
            }
            else{    
                int por10;
                por10=(suma2*13/100);
                pago_semanalA=(suma2+por10+200);
                System.out.println("el pago semanal del vendedor en la categoria B es: "+pago_semanalA);
            }
        }
        System.out.println("la suma es: "+suma);
    } 
}
