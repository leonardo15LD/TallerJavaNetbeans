/*
Escribe un programa en java que realice los siguientes cálculos: 
• Imprimir la tabla de votaciones, incluyendo sus cabeceras
• Calcular e imprimir el número total de votos recibidos por cada candidato y su porcentaje de votación con
relación al total de votos emitidos. Indicar cuál ha sido el candidato más votado (En caso de empate, se
escoge a cualquiera).
• Si algún candidato recibe más del 50% de los votos, el programa imprimirá un mensaje declarándole
ganador.
• Cual fue la comuna que mayor porcentaje de votación tuvo (En caso de empate, se escoge cualquiera)
 */
package punto5;

public class codigo_punto5 {
    public static void main(String args[]){
        int votaciones[][];
        votaciones= new int[5][4];
        votaciones[0][0] = 194;
	votaciones[0][1] = 48;
	votaciones[0][2] = 206;
	votaciones[0][3] = 45;
	votaciones[1][0] = 180;
        votaciones[1][1] = 20;
	votaciones[1][2] = 320;
	votaciones[1][3] = 16;
	votaciones[2][0] = 221;
	votaciones[2][1] = 90;
	votaciones[2][2] = 140;
	votaciones[2][3] = 20;
	votaciones[3][0] = 432;
	votaciones[3][1] = 50;
	votaciones[3][2] = 821;
	votaciones[3][3] = 14;
	votaciones[4][0] = 820;
	votaciones[4][1] = 61;
	votaciones[4][2] = 946;
	votaciones[4][3] = 18;
        System.out.println("|Columna|   "+"|Candidato A|   "+"|Candidato B|   "+"|Candidato C|   "+"|Candidato D|   ");
        int col=0;
        int i=0;
        double suma_total=0;
        double sumafil1=0,sumafil2=0,sumafil3=0,sumafil4=0;
        for (i=1;i<6;i++){
            col=col+1;
            System.out.println("    "+"|"+col+"|"+"         "+"|"+votaciones[i-1][0]+"|"+"           "+"|"+votaciones[i-1][1]+"|"+"           "+"|"+votaciones[i-1][2]+"|"+"           "+"|"+votaciones[i-1][3]+"|");
            sumafil1+=votaciones[i-1][0];
            sumafil2+=votaciones[i-1][1];
            sumafil3+=votaciones[i-1][2];
            sumafil4+=votaciones[i-1][3];
            suma_total=sumafil1+sumafil2+sumafil3+sumafil4;
        }
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("la suma total de votos es: "+suma_total);
        System.out.println("La suma de votos obtenidos del canditado A es: "+sumafil1);
        System.out.println("La suma de votos obtenidos del canditado B es: "+sumafil2);
        System.out.println("La suma de votos obtenidos del canditado C es: "+sumafil3);
        System.out.println("La suma de votos obtenidos del canditado D es: "+sumafil4);
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("El candidato con mas votaciones fue el C con : "+sumafil3+" votos ");
        double porcentajeA,porcentajeB,porcentajeC,porcentajeD;
        porcentajeA=sumafil1*100/suma_total;
        porcentajeB=sumafil2*100/suma_total;
        porcentajeC=sumafil3*100/suma_total;
        porcentajeD=sumafil4*100/suma_total;
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("el porcentaje de votos del candidato A es del: %.2f %n",porcentajeA);
        System.out.printf("el porcentaje de votos del candidato B es del: %.2f %n",porcentajeB);
        System.out.printf("el porcentaje de votos del candidato C es del: %.2f %n",porcentajeC);
        System.out.printf("el porcentaje de votos del candidato D es del: %.2f %n",porcentajeD);
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("EL GANADOR DE LAS VOTACIONES HA SIDO EL CANDITADO C ");
        System.out.println("CON UNA CANTIDAD DE VOTOS DE: "+sumafil3);
        System.out.printf("CON UN PORCENTAJE DEL: %.2f %n",porcentajeC);
        System.out.println("-------------------------------------------------------------------------");
        for (int x = 0; x < votaciones.length; x++) {
            int sumax = 0;
            for (int b = 0; b < votaciones[x].length; b++) {
                System.out.printf("%d ", votaciones[x][b]);
                sumax += votaciones[x][b];
            }
            System.out.printf("= %d %n", sumax);
        }   System.out.println("la comuna  con mas votos es la 5");
        System.out.println("-------------------------------------------------------------------------");
 
    }
}
