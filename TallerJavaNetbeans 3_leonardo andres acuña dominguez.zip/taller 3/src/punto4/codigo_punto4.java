/*
Desarrolle una aplicación en Java que determine el sueldo bruto para un conjunto de empleados. La empresa paga
una tarifa normal por hora en las primeras 40 horas de trabajo de cada empleado, y en todas las horas trabajadas que
excedan de 40 paga por hora tarifa y media.
Usted recibe un arreglo E con los nombres de los empleados de la empresa, un arreglo H con el número de horas que
trabajó cada uno en la semana y un arreglo T con la tarifa por horas normal de cada empleado.
Con estos datos el programa debe determinar y mostrar el sueldo bruto de cada trabajador. 
 */
package punto4;
import java.util.Scanner;
public class codigo_punto4 {
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        int numero_empleados;
        System.out.println("escriba la cantidad de empleados: ");
        numero_empleados=entrada.nextInt();
        String[]nombres1= new String[numero_empleados];
        String aux;
        double tarifa_media;
        double horas_extras;
        double salario_semanal;
        int []hora_trabajadas= new int[numero_empleados];
        double []tarifa_normal= new double[numero_empleados];
        for (int i=0;i<nombres1.length;i++){
            System.out.print("escriba el nombre del empleado "+(i+1)+":");
            aux=entrada.next();
            nombres1[i]=aux;
        }
        for (int i=0;i<numero_empleados;i++){
            System.out.println("escriba el numero de horas trabajadas a la semana del empleado "+nombres1[i]+" :");
            hora_trabajadas[i]=entrada.nextInt();
            System.out.println("escriba la tarifa por horas normales del empleado "+nombres1[i]+" :");
            tarifa_normal[i]=entrada.nextDouble();
            tarifa_media=(tarifa_normal[i]+tarifa_normal[i]/2);
            if (hora_trabajadas[i]>40){
                horas_extras=(hora_trabajadas[i]-40);
                salario_semanal=(horas_extras*tarifa_media)+(40*tarifa_normal[i]);
                System.out.println("el salario del empleado "+nombres1[i]+" es :"+salario_semanal);
            }
            else{
                if (hora_trabajadas[i]<=40){
                    salario_semanal=hora_trabajadas[i]*tarifa_normal[i];
                    System.out.println("el salario del empleado "+nombres1[i]+" es :"+salario_semanal);
                }
            }
        }
    }
}
